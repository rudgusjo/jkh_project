<!--태그 크기조절-->
<!--<!DOCTYPE html>

<html>

<head>

<title></title>

<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">





<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script
  src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

</head>

<body>



<div id="resizable"  style="width:200px;height:160px;	border: 1px solid black;">

	<img src="http://img.imnews.imbc.com/news/2016/culture/article/__icsFiles/afieldfile/2016/09/08/4_5.jpg" style="width:100%;height:100%">

</div>



<script language = "javascript">
$(document).ready(function(){

    $( "#resizable" ).resizable();
});
</script>





</body>

</html>-->



<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>부스배치도</title>
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/smoothness/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <style>
    .wrapper{
      width: 1400px;
      height: 650px;
    }
    .draggable {
      margin-left: 50px;
      border: 1px solid black;
      width: 800px;
      height: 600px;
      float: left;
    }

    .content{
      border: 1px solid black;
      width: 150px;
      height: 600px;
      float: left;
    }
    .booth{
      margin-left: 10px;
      margin-top: 10px;
      border: 1px solid black;
      width: 98px;
      height: 98px;
    }

    .boothContent{
      border: 1px solid black;
      margin-left: 10px;
      margin-top: 10px;
      width: 98px;
      height: 98px;
    }
    .booth_su p {
      margin:2px;
    }
    .booth_su{
      border: 1px solid black;
      width:150px;
      height:30px;
      float:left;
    }
    .booth_del{
      margin-left:50px;
      border: 1px solid black;
      width:800px;
      height:150px;
      float:left;
      text-align: center;
    }
    .footer{
      width:1400px;
      height:300px;
    }


  </style>
  <script>
      $(function() {

          var boothObjArr = Array(); //객체 부스 넣는 배열
          var boothAttrArr = Array();
          var user_name = "{{$user['email']}}"; //유저 정보
          $(document.body).on('click','#finish',function(){
              for(var count = 0, count2 = 0, leng = boothObjArr.length; count < leng ; count++){
                  //현재 작업장에 올려진 부스를 php에 넘기기에 알맞은 형태로 가공하기 위한 for문
                  boothAttrArr[count] = {
                      //객체에서 메소드를 제외한 좌표,넓이값만 저장하기 위한 연관배열
                      'top'   : 0,
                      'left'  : 0,
                      'width' : 0,
                      'height': 0
                      //배치도의 기본 크기는 98
                  };
                  for(var attr in boothObjArr[count]){//각 부스마다의 키값 추출
                      if(typeof(boothObjArr[count][attr]) == typeof(function(){}))  break;
                      //부스객체에서 좌표값, 넓이값 이후, 메서드를 저장하려고 하면 break
                      if(typeof(boothAttrArr[count]) != typeof(Array())){//값 저장을 위한 초기화
                          boothAttrArr[count] = Array();
                      }
                      boothAttrArr[count][attr] = Number(boothObjArr[count][attr].toFixed(1));
                    /*attr로 설정하고 넘기게 되면 자바스크립트에서는 연관배열(객체화)로 취급되어지지만 php로 넘어가는 순간 형식상 깨지는 현상 발생..... index로 넘기게 되면 값이 넘어가게 되지만 db입력 시에 논리적 모순 발생*/
                  }
              }
              $.ajax({/*서버에 값 전달*/
                  url : 'http://localhost:8000/booth/save',
                  data: {
                      boothArr : boothAttrArr,
                      booth_name : '안녕', // 부스네임 임의 지정
                      user_name :user_name // 유저네임 세션을 통해 가져옴
                  },
                  dataType : 'jsonp',
                  success : function(data){
                      console.log(data[0]['top']);
                      alert('저장이 완료되었습니다.');
                      window.location.href = "<?php echo URL::to('/'); ?>";
                  },
                  error : function(){
                      console.log(boothAttrArr);
                      alert('에러가 발생하였습니다');
                  }
              });
          });

          // 부스 초기화 기능
          $('#reset').click(function(){
              if(boothObjArr.length<1)
                  alert('초기화 할 부스가 없습니다!');
              else{
                  if(confirm("현재 배치된 부스들이 다 사라집니다. 정말 초기화 하시겠습니까?")){
                      if(confirm("알겠습니다. 만일을 대비해 한번 더 질문합니다. 정말 초기화 합니까?")){
                          $('.boothContent').remove();
                          for(var i=0 ,arrLength = boothObjArr.length; i<arrLength;i++){
                              boothObjArr.shift();
                          }
                          $('.booth_su_count').text('현재 부스수:'+Number(boothObjArr.length));
                      } else {
                          alert('역시 ㅎ');
                      }
                  } else {
                      alert('싱겁기는..');
                  }
              }
          });

          $( ".booth" ).draggable({
              grid: [10, 10],
              snap: true,
              stop:function(){

                  //현재 부스 수를 표시
                  $('.booth_su_count').text('현재 부스수:'+Number(boothObjArr.length+1));
                  function boothObj(){/*부스 클래스*/
                      this.top    = 0;
                      this.left   = 0;
                      this.width  = 98; //기본 크기
                      this.height = 98;
                      this.booth;

                      this.getTop = function(){
                          return this.top;
                      }
                      this.getLeft = function(){
                          return this.left;
                      }
                      this.setTop = function(argTop){
                          this.top = argTop;
                      }
                      this.setLeft = function(argLeft){
                          this.left = argLeft;
                      }
                      this.setWidth = function(argWidth){
                          this.width = argWidth;
                      }
                      this.setHeight = function(argHeight){
                          this.height = argHeight;
                      }
                      this.getWidth = function(){
                          return this.width;
                      }
                      this.getHeight = function(){
                          return this.height;
                      }

                      this.getBooth = function(){
                          return this.booth;
                      }
                      this.setBooth = function(argBooth){
                          this.booth = argBooth;
                      }
                  }

                  var boothLeft     = Number($(this).offset().left);
                  var boothTop      = Number($(this).offset().top);
                  var boardLeft     = Number($('.draggable').offset().left);
                  var boardTop      = Number($('.draggable').offset().top);
                  var boardWidth    = Number($('.draggable').width());
                  var boothWidth    = Number($('.booth').width());
                  var boardHeight   = Number($('.draggable').height());
                  var boothHeight   = Number($('.booth').height());

                  // 쓰레기통의 값들
                  var garbageLeft   = Number($('.booth_del').offset().left);
                  var garbageTop    = Number($('.booth_del').offset().top);
                  var garbageWidth  = Number($('.booth_del').width());
                  var garbageHeight = Number($('.booth_del').height());

                /*작업영역에 완벽하게 들어가지 않았을 경우 원래자리로 초기화*/
                  if(boothLeft <= boardLeft ||
                      boothLeft >= boardLeft + boardWidth  - boothWidth ||
                      boothTop  <= boardTop  ||
                      boothTop  >= boardTop  + boardHeight - boothHeight){

                      $(this).css({
                          "top":"0px",
                          "left":"0px"
                      });
                      return;
                  }
                  //====================

                /*작업장에 올라와있는 부스 요소의 id속성 get 및 부스간 충돌 판정*/
                  if($('.boothContent').length){
                      for(var i = 0, length = boothObjArr.length; i < length; i++){
                          if((boothLeft+boothWidth) > boothObjArr[i].getLeft() &&
                              boothLeft < (boothObjArr[i].getLeft() + boothObjArr[i].getBooth().width()) &&
                              (boothTop+boothHeight) > boothObjArr[i].getTop() &&
                              boothTop < (boothObjArr[i].getTop() + boothObjArr[i].getBooth().height())){
                              $(this).css({
                                  "top":"0px",
                                  "left":"0px"
                              });
                              return;
                          }
                      }

                      var id = $('.boothContent').last().attr('id');
                      var idArr = id.split('_');
                      var idValue = Number(idArr[1])+1;
                  }else{
                      var idValue = 1;
                  }
                  //====================

                  var booth = "<div class='boothContent' id=content_" + idValue + "><p>BOOTH_"+idValue+"</p></div>";
                /*부스객체 추가, 부스도형 초기화 및 작업장에 부스 추가*/
                  $(".draggable").append(booth);
                  var boothObj = new boothObj();

                  boothObj.setBooth($('#content_'+idValue));
                  boothObj.setTop(boothTop);
                  boothObj.setLeft(boothLeft);

                  boothObjArr.push(boothObj);

                  $('#content_'+idValue).css({
                      "position":"absolute",
                      "top": boothTop-10,
                      "left": boothLeft-10
                  });

                  $(this).css({
                      "top":"0px",
                      "left":"0px"
                  });
                  //==================================



                /*작업장에 추가된 부스요소의 크기조절 및 draggable속성 추가 및 옵션설정*/
                  $('.boothContent').resizable({
                      start:function(){
                          //현재의 위치값과 배치도의 크기를 계산하여 배치도를 넘어가지 않게 함
                          var thisLeft     = Number($(this).offset().left);
                          var thisTop      = Number($(this).offset().top);
                          $(this).resizable( "option", "maxWidth", (boardWidth-thisLeft+boardLeft) );
                          $(this).resizable( "option", "maxHeight", (boardHeight-thisTop+boardTop) );
                      },
                      grid: [50,50],
                      minHeight: 98, //최소 부스 크기
                      minWidth: 98,  //최소 부스 크기
                      stop:function(){
                          // 간단한 사이즈 표시
                          var thisWidth    = Number($(this).width());
                          var thisHeight   = Number($(this).height());
                          var thisLeft     = Number($(this).offset().left);
                          var thisTop      = Number($(this).offset().top);

                          var id = $(this).attr('id');

                          for(var i = 0, length = boothObjArr.length; i < length; i++){
                              if(id == boothObjArr[i].getBooth().attr('id')){
                                  continue;
                              }
                              if((thisLeft+thisWidth) > boothObjArr[i].getLeft() &&
                                  thisLeft < ( boothObjArr[i].getLeft() + boothObjArr[i].getBooth().width()) &&
                                  (thisTop+thisHeight) > boothObjArr[i].getTop() &&
                                  thisTop < (boothObjArr[i].getTop() + boothObjArr[i].getBooth().height())){
                                  for(var i = 0, length = boothObjArr.length; i < length ; i++){

                                      if(id == boothObjArr[i].getBooth().attr('id')){
                                          window.alert('부스가 겹칩니다');
                                          $(this).css({
                                              "width":boothObjArr[i].getWidth(),
                                              "height":boothObjArr[i].getHeight()
                                          });
                                          return;
                                      }
                                  }
                              }
                          }

                          // 각 부스별 사이즈를 표시
                          for(var i = 0, length = boothObjArr.length; i < length ; i++){
                              if(id == boothObjArr[i].getBooth().attr('id')){
                                  boothObjArr[i].setWidth(thisWidth);
                                  boothObjArr[i].setHeight(thisHeight);
                                  $(this).children('p').html('사이즈 : '+(thisWidth+2)+' X '+(thisHeight+2)
                                      +"<br>"+boothObjArr[i].getWidth()+" "+boothObjArr[i].getHeight());
                              }
                          }

                      }
                  }).draggable({
                      grid: [10,10],
                      snap: true,
                      stop:function(){
                          var thisLeft     = Number($(this).offset().left);
                          var thisTop      = Number($(this).offset().top);
                          var thisWidth    = Number($(this).width());
                          var thisHeight   = Number($(this).height());

                          var id = $(this).attr('id');

                        /*부스간 충돌방지*/
                          for(var i = 0, length = boothObjArr.length; i < length; i++){
                              if(id == boothObjArr[i].getBooth().attr('id')){
                                  continue;
                              }
                              if((thisLeft+thisWidth) > boothObjArr[i].getLeft() &&
                                  thisLeft < ( boothObjArr[i].getLeft() + boothObjArr[i].getBooth().width()) &&
                                  (thisTop+thisHeight) > boothObjArr[i].getTop() &&
                                  thisTop < (boothObjArr[i].getTop() + boothObjArr[i].getBooth().height())){
                                  for(var i = 0, length = boothObjArr.length; i < length ; i++){

                                      if(id == boothObjArr[i].getBooth().attr('id')){
                                          $(this).css({
                                              "top":boothObjArr[i].getTop() -10,
                                              "left":boothObjArr[i].getLeft() -10
                                          });
                                          return;
                                      }
                                  }
                              }
                          }
                          //=========================

                          //==================================================
                          // 부스 삭제

                          if(thisLeft >= garbageLeft &&
                              thisLeft <= Number(garbageLeft + garbageWidth - thisWidth) &&
                              thisTop  >= garbageTop  &&
                              thisTop  <= garbageTop + 500){

                              for(var i = 0, length = boothObjArr.length; i < length ; i++){
                                  if(id == boothObjArr[i].getBooth().attr('id')){
                                      boothObjArr[i]='';
                                      $(this).remove();
                                      boothObjArr.sort();
                                      boothObjArr.shift();
                                      //현재 부스 수를 표시
                                      $('.booth_su_count').text('현재 부스수:'+Number(boothObjArr.length));
                                      return;
                                  }
                              }
                          }

                        /*작업장 안의 부스요소가 작업장을 벗어나는 것을 방지*/
                          if(thisLeft <= boardLeft ||
                              thisLeft >= Number(boardLeft + boardWidth - thisWidth) ||
                              thisTop  <= boardTop  ||
                              thisTop  >= boardTop + boardHeight - thisHeight + 10){

                              for(var i = 0, length = boothObjArr.length; i < length ; i++){

                                  if(id == boothObjArr[i].getBooth().attr('id')){
                                      $(this).css({
                                          "position":"absolute",
                                          "top":boothObjArr[i].getTop() -10,
                                          "left":boothObjArr[i].getLeft() -10
                                      });
                                      return;
                                  }

                              }
                          }else{    /*작업장을 벗어나지 않고 이동했을 경우 객체에 좌표초기화*/
                              for(var i = 0, length = boothObjArr.length; i < length ; i++){
                                  if(id == boothObjArr[i].getBooth().attr('id')){
                                      boothObjArr[i].setTop(thisTop);
                                      boothObjArr[i].setLeft(thisLeft);
                                  }
                              }
                          }
                      }
                  });
                  //===================
              }
          });
      });
  </script>
</head>
<body>

<div class="wrapper">
  <div class="content">
    <div class="booth">BOOTH </div>
    <div class="booth">BOOTH </div>
    <div class="booth">BOOTH </div>
  </div>

  <div class="draggable ui-widget-content">
  </div>
  <button id="finish" class="ui-button ui-widget ui-corner-all" style="margin-left: 10px; width:120px; height:70px; font-weight: bold;">제작완료</button>
  <br>
  <button id="reset" class="ui-button ui-widget ui-corner-all" style="margin-left: 10px; margin-top:10px; width:120px; height:70px; font-weight: bold;">초기화</button>
</div>
<div class="footer">
  <div class="booth_su">
    <p class="booth_su_count">현재 부스수:0</p>
  </div>
  <div class="booth_del">
    <img src="http://www.coatesville.org/website/wp-content/uploads/2010/12/trash-can.jpg" width="150"height="150">
  </div>
</div>

</body>
</html>
