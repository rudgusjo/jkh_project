<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMyshopTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('myshop', function (Blueprint $table) {
            $table->integer('user_id')->foreign('user_id')->references('users')->on('id');
            //회원 고유번호와 연동해야됨
            $table->increments('id');
            $table->string('title');
            $table->string('text'); //소개
            $table->string('filename'); //설정파일명
            $table->integer('max_result'); //최고판매금액
            $table->integer('min_result'); //최저판매금액
            $table->integer('join_count'); //참가횟수
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('myshop');
    }
}
