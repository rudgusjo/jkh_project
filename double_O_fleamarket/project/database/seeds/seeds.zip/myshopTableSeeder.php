<?php

use Illuminate\Database\Seeder;

class myshopTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('myshop')->insert([
            'user_id' => 1,
            'title' => '조경현마이샵',
            'text' => '하이염',
            'filename' => 'default',
            'max_result' => 500000,
            'min_result' => 10000,
            'join_count' => 3
        ]);
        DB::table('myshop')->insert([
            'user_id' => 2,
            'title' => '킨미라이샵',
            'text' => '킄킄',
            'filename' => 'default',
            'max_result' => 250000,
            'min_result' => 100000,
            'join_count' => 5
        ]);
        DB::table('myshop')->insert([
            'user_id' => 3,
            'title' => '즈어진규샵',
            'text' => '케케',
            'filename' => 'default',
            'max_result' => 350,
            'min_result' => 120,
            'join_count' => 720
        ]);
    }
}
