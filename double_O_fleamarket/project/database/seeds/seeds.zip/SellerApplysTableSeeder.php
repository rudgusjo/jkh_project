<?php

use Illuminate\Database\Seeder;

class SellerApplysTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('SellerApplys')->insert([
            'th_id' => '1',
            'user_id' => '1',
            'accept' => false,
            'booth_name' => '흑인부스',
            'category'   => '음식'
        ]);
        DB::table('SellerApplys')->insert([
            'th_id' => '2',
            'user_id' => '2',
            'accept' => false,
            'booth_name' => '킨미라이부스',
            'category'    => '꿈과희망'
        ]);
        DB::table('SellerApplys')->insert([
            'th_id' => '3',
            'user_id' => '3',
            'accept' => false,
            'booth_name' => '즈어즈인규부스',
            'category' => 'IT'
        ]);
    }
}
