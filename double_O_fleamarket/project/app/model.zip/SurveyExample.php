<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SurveyExample extends Model
{
    //
}
