<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class flea_th extends Model
{
    //
}
